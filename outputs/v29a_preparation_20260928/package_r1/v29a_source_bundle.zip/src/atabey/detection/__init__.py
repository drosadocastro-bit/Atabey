"""Detection utilities."""
