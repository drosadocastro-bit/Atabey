"""State layer primitives."""
