"""IO adapter boundaries."""
