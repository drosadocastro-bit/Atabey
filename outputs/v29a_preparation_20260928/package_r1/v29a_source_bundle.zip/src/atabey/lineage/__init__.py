"""Lineage graph helpers."""
